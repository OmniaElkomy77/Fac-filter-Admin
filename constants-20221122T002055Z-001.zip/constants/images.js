export const location = require('../assets/images/location.png');
export const noImage = require('../assets/images/noImage.jpg');
export const user = require('../assets/images/user.png');

export default {location, noImage, user};

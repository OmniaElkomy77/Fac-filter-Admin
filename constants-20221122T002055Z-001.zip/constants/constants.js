const GOOGLE_MAP_API_KEY = "API KEY";

export default {
  GOOGLE_MAP_API_KEY,
};

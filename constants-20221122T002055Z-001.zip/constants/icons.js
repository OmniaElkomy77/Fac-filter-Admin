const location_pin1 = require("../assets/icons/location_pin1.png");

export default {
  location_pin1,
};
